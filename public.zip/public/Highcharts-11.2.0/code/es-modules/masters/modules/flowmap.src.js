/**
 * @license Highcharts JS v11.2.0 (2023-10-30)
 * @module highcharts/modules/flowmap
 * @requires highcharts
 *
 * (c) 2009-2022
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/FlowMap/FlowMapSeries.js';
